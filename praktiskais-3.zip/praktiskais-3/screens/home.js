import React, {useState} from 'react';
import { StyleSheet, View, Text, Button, TouchableOpacity} from 'react-native';
import { globalStyles } from '../styles/global';


export default function Home({ navigation }) {
const [count, setCount] = useState(0);


  const pressHandler = () => {
    navigation.push('ReviewDetails');
  }

  return (
    <View style={globalStyles.container}>
      <Button title='List with entries' onPress={pressHandler} />
 

      <View style={styles.container}>
      <Button
        onPress={() => setCount(count + 1)}
        title="Increase Amount"
      />
      <Button
        onPress={() => setCount(count - 1)}
        title="Decrease amount"
      />
      <Text>You clicked {count} times</Text>
    </View>

    </View>
  );

}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
})